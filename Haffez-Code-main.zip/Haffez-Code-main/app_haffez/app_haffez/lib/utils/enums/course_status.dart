enum CourseStatus {
  started,
  notStarted,
  finished,
}
