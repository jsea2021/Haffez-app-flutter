enum PageType {
  currentCourses,
  finishedCourses,
}
