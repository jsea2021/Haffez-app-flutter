package com.example.haffez

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
